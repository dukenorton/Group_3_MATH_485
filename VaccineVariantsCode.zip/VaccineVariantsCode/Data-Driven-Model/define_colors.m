%define colors

blue=[0, 0.4470, 0.7410];
brown=[0.8500, 0.3250, 0.0980];
purple=[.5 0 .5];
olive=[.3 .4 .2];
light_olive=olive*0.8;
orange = [1 0.5 0];
light_orange=orange/25;
red =[1 0.2 0.2];
cyan =[0.2 0.8 0.8];
black=[0 0 0];
gray=[17 17 17]/25;
magenta=[1 0 1];
blue2=[0 0 1];
yellow=[1 1 0];
green=[0 1 0];
